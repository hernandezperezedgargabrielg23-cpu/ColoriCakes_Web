// Script básico para futuros efectos
console.log('Colori Cakes web cargada correctamente');